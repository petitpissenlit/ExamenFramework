package be.ehb.examen.model;

import org.springframework.data.repository.CrudRepository;

public interface VerhuurdDao extends CrudRepository<Verhuurd, Integer> {
}
