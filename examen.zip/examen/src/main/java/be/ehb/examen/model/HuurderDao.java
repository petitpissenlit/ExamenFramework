package be.ehb.examen.model;

import org.springframework.data.repository.CrudRepository;

public interface HuurderDao extends CrudRepository<Huurder, Integer> {
}
