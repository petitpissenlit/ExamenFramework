package be.ehb.examen.model;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface AutoDao extends CrudRepository<Auto,Integer>{


}
