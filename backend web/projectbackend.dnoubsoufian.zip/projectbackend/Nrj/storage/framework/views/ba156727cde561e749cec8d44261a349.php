<?php if(Session::has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(Session::get('success')); ?>

    </div>
<?php endif; ?>



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Profiel van <?php echo e($user->name); ?></div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="text-center">
<img src="<?php echo e(asset('storage/' . $user->avatar)); ?>" alt="Avatar" width="50">
                            </div>
                        </div>
                        <div class="col-md-8">
                            <h4>Gebruikersnaam:</h4>
                            <p><?php echo e($user->name); ?></p>

                            <h4>Geboortedatum:</h4>
                            <p><?php echo e($user->birthday); ?></p>

                            <h4>About me:</h4>
                            <p><?php echo e($user->bio); ?></p>
                        </div>
                    </div>

                    <hr>

                    <h2>Gemaakte Posts</h2>

                    <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('posts.show', $post->id)); ?>"><?php echo e($post->title); ?></a><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <hr>

                    <h2>Gelikete Posts</h2>
                    <?php $__currentLoopData = $user->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('posts.show', $like->post_id)); ?>"><?php echo e($like->post->title); ?></a><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="card-footer">
                        <button class="btn btn-primary" type="button" data-bs-toggle="collapse"
                            data-bs-target="#profileOptions" aria-expanded="false" aria-controls="profileOptions">
                            Edit profile
                        </button>

                        <div class="collapse mt-3" id="profileOptions">
                            <form action="<?php echo e(route('profile.update', ['name' => $user->name])); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="mb-3">
                                    <label for="name" class="form-label">Gebruikersnaam</label>
                                    <input type="text" class="form-control" id="name" name="name"
                                        value="<?php echo e($user->name); ?>" required>
                                </div>

                                <div class="mb-3">
                                    <label for="email" class="form-label">E-mail</label>
                                    <input type="email" class="form-control" id="email" name="email"
                                        value="<?php echo e($user->email); ?>" required>
                                </div>

                                <div class="mb-3">
                                    <label for="password" class="form-label">Nieuw wachtwoord</label>
                                    <input type="password" class="form-control" id="password" name="password"
                                        placeholder="Nieuw wachtwoord">
                                </div>

                                <div class="mb-3">
                                    <label for="bio" class="form-label">Over mij</label>
                                    <textarea class="form-control" id="bio" name="bio"
                                        required><?php echo e($user->bio); ?></textarea>
                                </div>

                                <div class="mb-3">
                                    <label for="avatar" class="form-label">Avatar</label>
                                    <input type="file" class="form-control" id="avatar" name="avatar">
                                </div>

                                <button type="submit" class="btn btn-primary">Opslaan</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Soufian\Documents\ehb\backend web\projectbackend\Nrj\resources\views/users/profile.blade.php ENDPATH**/ ?>