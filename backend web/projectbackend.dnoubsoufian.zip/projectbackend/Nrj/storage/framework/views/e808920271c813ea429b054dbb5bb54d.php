

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Alle artikelen</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                     <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="post-details">
                            <h3><a href="<?php echo e(route('posts.show',$post->id)); ?>"><?php echo e($post->title); ?></a></h3>
                            <!-- Ajoutez ici d'autres détails de l'article que vous souhaitez afficher -->
                            <small>Gepost door <a href="<?php echo e(route('profile', $post->user->name)); ?>"><?php echo e($post->user->name); ?></a> op <?php echo e($post->created_at->format('d/m/Y \o\m H:i')); ?></small>
                            <?php if(auth()->guard()->check()): ?>
                            <?php if($post->user_id == Auth::user()->id): ?>
                            <a href="<?php echo e(route('posts.edit', $post->id)); ?>">Edit post</a>
                            <?php else: ?>
                            <a href="<?php echo e(route('like',$post->id )); ?>">Like post</a>
                            <?php endif; ?>
                            <br>
                            <?php endif; ?>
                            Post heeft <?php echo e($post->likes->count()); ?> likes
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Soufian\Documents\ehb\backend web\projectbackend\Nrj\resources\views/posts/index.blade.php ENDPATH**/ ?>