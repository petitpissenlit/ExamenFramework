

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>FAQ</h1>

        <div class="row">
            <div class="col-md-6">
                <h2>After-service</h2>
                 
                 <?php
                    $afterServiceQuestions = [];
                ?>

                <ul>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($category->name === 'After-service'): ?>
                            <?php $__currentLoopData = $category->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $afterServiceQuestions[] = [
                                        'question' => $question->question,
                                        'answer' => $question->answer
                                    ];
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                
                <!-- Toevoegen van een nieuw vraag- en antwoordpaar voor After-service -->
                <h3>Nieuw vraag- en antwoordpaar</h3>
                <form method="POST" action="<?php echo e(route('faq.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="category" value="After-service">
                    <div class="mb-3">
                        <label for="question">Titel</label>
                        <input type="text" name="question" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="answer">Vraag</label>
                        <textarea name="answer" class="form-control" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Opslaan</button>
                </form>

                <!-- Succesbericht weergeven -->
                <?php if(session('success')): ?>
                    <div class="alert alert-success mt-3">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="col-md-6">
                <h2>Vragen over ons</h2>

                 <?php
                    $afterServiceQuestions = [];
                ?>

                <ul>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($category->name === 'After-service'): ?>
                            <?php $__currentLoopData = $category->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $afterServiceQuestions[] = [
                                        'question' => $question->question,
                                        'answer' => $question->answer
                                    ];
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <!-- Toevoegen van een nieuw vraag- en antwoordpaar voor Vragen over ons -->
                <h3>Nieuw vraag- en antwoordpaar</h3>
                <form method="POST" action="<?php echo e(route('faq.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="category" value="Vragen over ons">
                    <div class="mb-3">
                        <label for="question">Titel</label>
                        <input type="text" name="question" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="answer">Vraag</label>
                        <textarea name="answer" class="form-control" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Opslaan</button>
                </form>

                <!-- Succesbericht weergeven -->
                <?php if(session('success')): ?>
                    <div class="alert alert-success mt-3">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Soufian\Documents\ehb\backend web\projectbackend\Nrj\resources\views/faq/index.blade.php ENDPATH**/ ?>