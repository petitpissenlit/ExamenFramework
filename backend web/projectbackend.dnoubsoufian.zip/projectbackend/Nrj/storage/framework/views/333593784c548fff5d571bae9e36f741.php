

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>FAQ</h1>
    <?php if(Auth::user()->isAdmin()): ?>

        <div class="accordion" id="faqAccordion">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="heading<?php echo e($category->id); ?>">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($category->id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($category->id); ?>">
                            <?php echo e($category->name); ?>

                        </button>
                    </h2>
                    <div id="collapse<?php echo e($category->id); ?>" class="accordion-collapse collapse" aria-labelledby="heading<?php echo e($category->id); ?>" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <ul>
                                <?php $__currentLoopData = $category->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="faq-question">
                                        <strong><?php echo e($question->question); ?></strong><br>
                                        <div class="answer">
                                            <?php echo e($question->answer); ?>

                                        </div>
                                        <?php if(Auth::user()->isAdmin()): ?>
                                            <?php if($question->response): ?>
                                                <div class="response">
                                                    <strong>Response:</strong><br>
                                                    <?php echo e($question->response); ?>

                                                </div>
                                            <?php else: ?>
                                                <form action="<?php echo e(route('admin.faq.postResponse', $question->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="form-group">
                                                        <label for="response">Response:</label>
                                                        <textarea class="form-control" name="response" id="response" rows="3" required></textarea>
                                                    </div>
                                                    <button type="submit" class="btn btn-primary">Post Response</button>
                                                </form>
                                            <?php endif; ?>
                                            <form action="<?php echo e(route('admin.faq.delete', $question->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit">Verwijderen</button>
                                            </form>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <p>Je hebt geen toegang tot deze pagina.</p>
    <?php endif; ?>
</div>

<script>
    const faqQuestions = document.querySelectorAll('.faq-question');

    faqQuestions.forEach(question => {
        question.addEventListener('click', () => {
            question.querySelector('.answer').classList.toggle('show');
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Soufian\Documents\ehb\backend web\projectbackend\Nrj\resources\views/faq/faq-categories.blade.php ENDPATH**/ ?>