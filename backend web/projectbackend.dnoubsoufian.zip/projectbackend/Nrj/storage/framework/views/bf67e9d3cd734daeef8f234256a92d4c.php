

<?php $__env->startSection('content'); ?>
<h1>Gebruikersbeheer</h1>

<table>
    <thead>
        <tr>
            <th>Naam</th>
            <th>Email</th>
            <th>Acties</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.users.show', $user->id)); ?>">Bekijk</a>
                    <?php if($user->is_admin): ?>
                        <form id="demote-form-<?php echo e($user->id); ?>" action="<?php echo e(route('admin.users.demote', $user->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="hidden" name="_method" value="POST">
                            <button type="submit">Beeindig admin</button>
                        </form>
                    <?php else: ?>
                        <form id="promote-form-<?php echo e($user->id); ?>" action="<?php echo e(route('admin.users.promote', $user->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit">Bevorder tot admin</button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Soufian\Documents\ehb\backend web\projectbackend\Nrj\resources\views/admin/users.blade.php ENDPATH**/ ?>