

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e($post->title); ?></div>

                <div class="card-body">
                    

                    
                            <!-- Ajoutez ici d'autres détails de l'article que vous souhaitez afficher -->
                            <small>Gepost door <a href="<?php echo e(route('profile', $post->user->name)); ?>"><?php echo e($post->user->name); ?></a> op <?php echo e($post->created_at->format('d/m/Y \o\m H:i')); ?></small>
                            <br>
                            <?php echo e($post->message); ?>

<br><br>
                            <?php if($post->image): ?>
                                <img src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="Post Image" width="400">
                            <?php endif; ?>

                            <?php if(auth()->guard()->check()): ?>
                            <?php if($post->user_id == Auth::user()->id): ?>
                            <a href="<?php echo e(route('posts.edit', $post->id)); ?>">Edit post</a>
                            <?php else: ?>
                            <a href="<?php echo e(route('like',$post->id )); ?>">Like post</a>
                            <?php endif; ?>
                            <br>
                            <?php endif; ?>
                            Post heeft <?php echo e($post->likes->count()); ?> likes
                            <?php if(auth()->guard()->check()): ?>
                            <?php if(Auth::user()->is_admin): ?>
                            <br><br>
                            <form method="post" action="<?php echo e(route('posts.destroy', $post->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type="submit" value="DELETE POST" style="background-color:red;" onclick="return confirm('You sure?');">

                            </form>
                            <?php endif; ?>
                            <?php endif; ?>
                    
                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Soufian\Documents\ehb\backend web\projectbackend\Nrj\resources\views/posts/show.blade.php ENDPATH**/ ?>