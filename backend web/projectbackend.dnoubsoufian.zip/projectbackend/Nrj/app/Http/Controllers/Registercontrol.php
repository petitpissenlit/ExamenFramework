<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Registercontrol extends Controller
{
    //
}
