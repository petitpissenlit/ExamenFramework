<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>People Counter</title>
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
</head>
<body>

<nav class="navbar navbar-expand-md navbar-dark bg-dark mb-4">
    <a class="navbar-brand" href="#">People Counter</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="historiek.php">Log</a>
            </li>
        </ul>
    </div>
</nav>

<main role="main" class="container" id="detailContent">

    <h1>Log van bezoekersaantallen</h1>

    <div id="log" class="list-group">

      <!-- Toon alle logs met onderstaande layout, per log entry zal er een div aanwezig zijn -->
      <div class="list-group-item list-group-item-action flex-column align-items-start">
        <div class="d-flex w-100 justify-content-between">
          <h5 class="mb-1">-3 bezoekers <small>binnen</small></h5>
          <small>Vertrokken op 22-06-2021 13:30:00</small>
        </div>
        <p class="mb-1">Totaal aantal bezoekers <small>binnen</small>: 2</p>
      </div>

      <div class="list-group-item list-group-item-action flex-column align-items-start">
        <div class="d-flex w-100 justify-content-between">
          <h5 class="mb-1">+3 bezoekers <small>buiten</small></h5>
          <small>Toegekomen op 22-06-2021 13:25:00</small>
        </div>
        <p class="mb-1">Totaal aantal bezoekers <small>buiten</small>: 3</p>
      </div>

      <div class="list-group-item list-group-item-action flex-column align-items-start">
        <div class="d-flex w-100 justify-content-between">
          <h5 class="mb-1">+5 bezoekers <small>binnen</small></h5>
          <small>Toegekomen op 22-06-2021 13:20:00</small>
        </div>
        <p class="mb-1">Totaal aantal bezoekers <small>binnen</small>: 5</p>
      </div>
    </div>
</main>


</body>
</html>
