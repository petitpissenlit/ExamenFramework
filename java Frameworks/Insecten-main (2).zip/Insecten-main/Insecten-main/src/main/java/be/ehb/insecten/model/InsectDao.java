package be.ehb.insecten.model;

import org.springframework.data.repository.CrudRepository;

public interface InsectDao extends CrudRepository<Insect, Integer> {


}
