let naam = prompt("give me your name")
for (let i = 0; i < naam.length; i++){
    let letter = naam.charAt(i).toUpperCase();
    console.log(letter);
}
