function avg(a, b, c, d, e) {
    console.log(a, b, c, d, e);
    sum = a + b + c + d + e;
    console.log(sum);
    av = sum / 5;
    return (av);
        
}

const today = new Date();
console.log(today);

