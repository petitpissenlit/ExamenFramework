let firstname = 'Soufian';
let age = '23';
console.log(firstname)
console.log(age);