function cal(operator) {
    FirstOperator = document.getElementById('t1').value;
    f1 = parseFloat(FirstOperator);
    SecondeOperator = document.getElementById('t2').value;
    f2 = parseFloat(SecondeOperator);
    if (operator === '+') {
        result = f1 + f2;
    } else if (operator === '-') {
        result = f1 - f2;
    } else if (operator === '*') {
        result = f1 * f2;
    } else if (operator === '/') {
        result = f1 / f2;
    }
    if (isNaN(result)) {
        alert("Enter two numbers please");
    } else {
        s1 = document.getElementById('t3').value = result.toString();
    }
}
